﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository_project.Institute
{
    public class Teachers
    {
        public int teacherId { get; set; }
        public string teacherName { get; set; }
        public string Dsignation { get; set; }
        public double ContactNumber { get; set; }
        public string Subject { get; set; }
    }
}
